package us.mrvivacio.porno;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.Toast;



import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import androidx.appcompat.app.AppCompatActivity;

import static us.mrvivacio.porno.R.string.*;
import static us.mrvivacio.porno.R.string.alert_instructions_title;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "dawg";
    private Switch pornSwitch, bettingSwitch, socialMediaSwitch;

    // This holds the redirect links for MyAccessibilityService to refer to
    public static ArrayList<String> URLs;

    // This holds the latest porn domains from database
    public static Map<String, Boolean> realtimeBannedLinks = new HashMap<>();


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.toolbar, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        requestStoragePermissionsForSavingUserUrlData();

        if (!isAccessibilitySettingsOn(this)) {
            openAlertDialogForEnablingPorNoService();
        }

        pornSwitch = findViewById(R.id.porn_switch);
        bettingSwitch = findViewById(R.id.betting_switch);
        socialMediaSwitch = findViewById(R.id.social_media_switch);

        pornSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // Handle porn switch state change here
                if (isChecked) {
                    // Block browsing to porn websites
                } else {
                    // Unblock browsing to porn websites
                }
            }
        });

        bettingSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // Handle betting switch state change here
                if (isChecked) {
                    // Block browsing to betting websites
                } else {
                    // Unblock browsing to betting websites
                }
            }
        });

        socialMediaSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // Handle social media switch state change here
                if (isChecked) {
                    // Block browsing to social media websites
                } else {
                    // Unblock browsing to social media websites
                }
            }
        });
    }








    // To check if service is enabled
    private boolean isAccessibilitySettingsOn(Context mContext) {
        // Thank you, https://stackoverflow.com/questions/18094982/detect-if-my-accessibility-service-is-enabled
        int accessibilityEnabled = 0;
        final String service = getPackageName() + "/" + MyAccessibilityService.class.getCanonicalName();

        try {
            accessibilityEnabled = Settings.Secure.getInt(
                    mContext.getApplicationContext().getContentResolver(),
                    android.provider.Settings.Secure.ACCESSIBILITY_ENABLED);
//            Log.v(TAG, "accessibilityEnabled = " + accessibilityEnabled);
        } catch (Settings.SettingNotFoundException e) {
            Log.e(TAG, "Error finding setting, default accessibility to not found: "
                    + e.getMessage());
        }

        TextUtils.SimpleStringSplitter mStringColonSplitter = new TextUtils.SimpleStringSplitter(':');

        // TODO ?? this reports as true even when accessibility hasn't been enabled yet
        if (accessibilityEnabled == 1) {
            Log.v(TAG, "***ACCESSIBILITY IS ENABLED*** -----------------");
            String settingValue = Settings.Secure.getString(
                    mContext.getApplicationContext().getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (settingValue != null) {
                mStringColonSplitter.setString(settingValue);
                while (mStringColonSplitter.hasNext()) {
                    String accessibilityService = mStringColonSplitter.next();

//                    Log.v(TAG, "-------------- > accessibilityService :: " + accessibilityService + " " + service);
                    if (accessibilityService.equalsIgnoreCase(service)) {
//                        Log.v(TAG, "We've found the correct setting - accessibility is switched on!");
                        return true;
                    }
                }
            }
        } else {
            Log.v(TAG, "***ACCESSIBILITY IS DISABLED***");
        }

        return false;
    }

    private void openAlertDialogForEnablingPorNoService() {
        // Thank you, https://stackoverflow.com/questions/2115758
        AlertDialog.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            builder = new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert);
        } else {
            builder = new AlertDialog.Builder(this);
        }

        // Build the alert
        builder.setTitle(alert_disabled_title)
                .setMessage(alert_disabled_body)
                .setPositiveButton(R.string.alert_disabled_action, (dialog, which) -> {
                    // Open accessibility screen
                    Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                    startActivity(intent);
                })
//                .setNegativeButton("I'll go there myself", new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int which) {
//                        // Do nothing
//                    }
//                })
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }


    private void requestStoragePermissionsForSavingUserUrlData() {
        // Thank you, https://stackoverflow.com/questions/32635704/android-permission-doesnt-work-even-if-i-have-declared-it
        int PERMISSION_REQUEST_CODE = 1;

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_DENIED) {
                String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                requestPermissions(permissions, PERMISSION_REQUEST_CODE);
            }
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_DENIED) {
                String[] permissions = {Manifest.permission.READ_EXTERNAL_STORAGE};
                requestPermissions(permissions, PERMISSION_REQUEST_CODE);
            }
        }
    }



    /////// CORRESPONDS TO ACTION BAR MENU

    public void openAlertDialogForInstructions(MenuItem item) {
        AlertDialog.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            builder = new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert);
        } else {
            builder = new AlertDialog.Builder(this);
        }

        // Build the alert
        builder.setTitle(alert_instructions_title)
                .setMessage(alert_instructions_body)
                .setPositiveButton(alert_instructions_thank_you, (dialog, which) -> {
                    // doNothing()
                })
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    // Read from database, update banList, toast
    public void updateLinks(MenuItem item) {
        Toast.makeText(this, toast_database_off, Toast.LENGTH_LONG).show();
    }



}
